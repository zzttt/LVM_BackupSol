#include <jni.h>
#include <net_kkangsworld_lvmexec_NativePipe.h>
#include <android/log.h>
//android Jni include end //
//start C include //
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>

#define sysPATH "/data/data/net.kkangsworld.lvmexec/"
#define BUFF_SIZE 1024
#define LOGTAG "NDK_LVM"
#define CMDFIFO "/data/data/net.kkangsworld.lvmexec/cmd_pipe"
#define RESULTFIFO "/data/data/net.kkangsworld.lvmexec/result_pipe"

JNIEXPORT jstring JNICALL Java_net_kkangsworld_lvmexec_NativePipe_getMsg (JNIEnv *env, jobject)
{
	return env->NewStringUTF("Native Test");
}


/*
 * Pipe�� ��´�.
*/

void *getter_thread_main(void *arg)
{
	char* pmsg;
	int fiford;
	int err;
	int nbytes;
	errno = 0;

	char buff[BUFF_SIZE];
	char* cmdfifo = CMDFIFO;
	char* resultfifo = "/data/data/net.kkangsworld.lvmexec/result_pipe";
	char* syspath = sysPATH;

	__android_log_print(ANDROID_LOG_WARN, LOGTAG, "getter_thread_main : called getPipe()");


	//read mkfifo
	fiford = open(resultfifo, O_RDWR);
	if(fiford == -1) {
		//err = fiford;
		__android_log_write(ANDROID_LOG_ERROR, LOGTAG, strerror(errno));
	}
	else {
		__android_log_print(ANDROID_LOG_DEFAULT, LOGTAG, "fd number = %d", fiford);
		__android_log_write(ANDROID_LOG_DEBUG, LOGTAG, "opened resultfifo pipe");
	}

	while(1) {
		memset(buff, 0, sizeof(buff));
		nbytes = read(fiford, buff, strlen(buff));
		__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "fd number = %d", fiford);
		__android_log_write(ANDROID_LOG_ERROR, LOGTAG, strerror(errno));
		/*if(nbytes <= 0) {
			__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "nbytes size : %d", nbytes);
		}
		*/
		//else {
			__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "nbytes size : %d", nbytes);
			__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "data : %s\n", buff);
		//}
	}
	close(fiford);
}

int read_fifo()
{
	pthread_t p_tid[2];
	int thr_id;

	int a = 1;
	thr_id = pthread_create(&p_tid[0], NULL, &getter_thread_main, (void *)a);
		    if (thr_id < 0)
		    {
		    	__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "thread create error : ");
		        exit(0);
		    }
		    else {
		    	__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "thread created");
		    }

		    return 0;

}

JNIEXPORT jstring JNICALL Java_net_kkangsworld_lvmexec_NativePipe_test_1getPipe (JNIEnv *env, jobject)
{
	if(!read_fifo())
		return env->NewStringUTF("size 0");
	else
		return env->NewStringUTF("ok");
}

/* ***************** */


JNIEXPORT jstring JNICALL Java_net_kkangsworld_lvmexec_NativePipe_getPipe (JNIEnv *env, jobject)
{
	char* pmsg;
	int fiford;
	int err;
	int nbytes;
	errno = 0;

	char buff[BUFF_SIZE];
	char* cmdfifo = CMDFIFO;
	char* resultfifo = "/data/data/net.kkangsworld.lvmexec/result_pipe";
	char* syspath = sysPATH;

	__android_log_print(ANDROID_LOG_WARN, LOGTAG, "called getPipe()");


	//read mkfifo
	fiford = open(resultfifo, O_RDWR);
	if(fiford == -1) {
		//err = fiford;
		__android_log_write(ANDROID_LOG_ERROR, LOGTAG, strerror(errno));
	}
	else {
		__android_log_print(ANDROID_LOG_DEFAULT, LOGTAG, "fd number = %d", fiford);
		__android_log_write(ANDROID_LOG_DEBUG, LOGTAG, "opened resultfifo pipe");
	}

	//while(1) {
		memset(buff, 0, sizeof(buff));
		nbytes = read(fiford, buff, strlen(buff));
		//__android_log_write(ANDROID_LOG_DEBUG, LOGTAG, "read complete");
		//nbytes = read(fiford, (char *)&pmsg, sizeof(pmsg));
		__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "fd number = %d", fiford);
		__android_log_write(ANDROID_LOG_ERROR, LOGTAG, strerror(errno));
		if(nbytes <= 0) {
			__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "nbytes size : %d", nbytes);
			//return env->NewStringUTF("read failed size <= 0");
		}
		else {
		//printf("%s\n", buff);
			__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "nbytes size : %d", nbytes);
			__android_log_print(ANDROID_LOG_DEBUG, LOGTAG, "data : \n", buff);
		//return env->NewStringUTF(buff);
		}
	//}
	close(fiford);
	return env->NewStringUTF(buff);
}


/*
 * Pipe�� ����. mkfifo
 */
JNIEXPORT jint JNICALL Java_net_kkangsworld_lvmexec_NativePipe_writePipe (JNIEnv *env, jobject, jstring command)
{
	//mkfifo�� ��ġ�� static�ϰ� ���´�. �ٸ� application����ÿ��� �����ʿ�
	const char* PATH = sysPATH;
	//char* cmd_input = "lvdisplay -c"; //init for testing command.
	const char* cmd_input;
	int pipe;
	int fifowd, nbytes;
	int fiford;
	int err;
	errno = 0;
	char buff[BUFF_SIZE];
	char* syspath = sysPATH;
	char* resultfifo = RESULTFIFO;

	//copy command from Java to C
	cmd_input = env->GetStringUTFChars(command, 0);

	//open pipe use mkfifo (named)
	mode_t mode = S_IRWXU | S_IRWXG | S_IRWXO;

	pipe = mkfifo(CMDFIFO, mode);
	if(pipe == -1)
	{
		__android_log_write(ANDROID_LOG_ERROR, LOGTAG, "CMDFIFO make failed");
	}
	else
	{
		__android_log_write(ANDROID_LOG_DEFAULT, LOGTAG, "CMDFIFO make success");
	}


	//data ���� -- pipe open
	fifowd = open(CMDFIFO, O_WRONLY);

	//error ó��
	if(fifowd == -1) {
		__android_log_write(ANDROID_LOG_ERROR, LOGTAG, strerror(errno));
		return err;
	}

	//fifo write
	if( err == write(fifowd, cmd_input, strlen(cmd_input)) ) {
		__android_log_print(ANDROID_LOG_ERROR, LOGTAG, "err : %d\n",err);
		__android_log_write(ANDROID_LOG_ERROR, LOGTAG, strerror(errno));
	}

	else {
		__android_log_write(ANDROID_LOG_WARN, LOGTAG, "writing file completed.");
	}

	//close write pipe
	close(fifowd);

	return err;
}

