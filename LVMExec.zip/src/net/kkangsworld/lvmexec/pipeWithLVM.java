package net.kkangsworld.lvmexec;

import java.io.BufferedReader;
import java.io.FileReader;

import android.os.Handler;
import android.os.Message;
import android.util.Log;

public class pipeWithLVM {
	
	private NativePipe nativepipe;
	private ResultReader resultReader;
	private readHandler rHandler;
	
	public pipeWithLVM() {
		//constructor
		nativepipe = new NativePipe(); //Native comm init
		resultReader = new ResultReader(); //ResultReader thread init;
		resultReader.start();
		readFromPipe(); //read�� ���ÿ� ����
	}
	
	public pipeWithLVM(readHandler mHandler) {
		nativepipe = new NativePipe();
		this.rHandler = mHandler;
		resultReader = new ResultReader(this.rHandler); //ResultReader thread init;
		resultReader.start();
		//readFromPipe(); //read�� ���ÿ� ����
	}
	
	public void ActionWritePipe(String command) {
		
		nativepipe.writePipe(command);
		
	}
	
	public void ActionGetPipe() {
		readFromPipe();
		//String temp = nativepipe.getPipe();
		//Toast.makeText(getApplicationContext(), temp, Toast.LENGTH_SHORT).show();
	}

	
	private void readFromPipe() {
		
		
        
    }

}

class readHandler extends Handler {
	
	String readResult;
	public readHandler() {
	
	}
	
	public void handleMessage(Message msg) {
		Log.i("LVMJava", "ResultReader Handler result get");
		switch(msg.what) {
		case 0: //case 0
			//Toast.makeText(getApplicationContext(), (String)msg.obj, Toast.LENGTH_LONG).show();
			readResult = (String)msg.obj;
			Log.d("inAction", "[resultMsg] :"+(String)msg.obj);
			break;
		}	
			
	}
	
	public String readResult() {
		return readResult;
	}
}

class ResultReader extends Thread {
	
	Handler rHandler;
	public ResultReader() {
		
	}
	
	public ResultReader(Handler rHandler) {
		this.rHandler = rHandler;
		Log.i("LVMJava", "ResultReader thread init");
	}
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		Log.i("LVMJava", "ResultReader thread start");
		String path = "/data/data/net.kkangsworld.lvmexec/result_pipe";
			try
			{ 
				/* ���� package ����� result_pipe */
				//String path = getApplicationInfo().dataDir+"/result_pipe";
				
				/* return �� txt */
				String txt = "";
				//Log.i("LVMJava", "openning input stream");
				Log.i("LVMJava", path);
				
				//����ؼ� BufferedReade�� �Էµ� result pipe data�� gettering
				while(true) {
					Log.i("LVMJava", "run whiling..");
					BufferedReader reader = 
							 new BufferedReader(new FileReader(path));
				    while((txt = reader.readLine()) != null) 
				    {
				    	Log.d("LVMJava", txt);
				    	
				    	if(txt.contains("[in run_command]"))
				    			Log.d("LVMJava", "in run command get return");
				    	else {
					    	Message msg = Message.obtain();
							msg.what = 0; msg.arg1 = 0; //���⿡ �ش� COMMAND���п� �����ɵ�
							msg.obj = txt;
							rHandler.sendMessage(msg);
							//�� ������ use Handler
							Log.d("LVMJava", "To handler success");	
				    	}
						
				    } 
				    reader.close();
			    }
				
			 
			 }catch(Exception e) {
				 e.printStackTrace();
				 }
		}
}
