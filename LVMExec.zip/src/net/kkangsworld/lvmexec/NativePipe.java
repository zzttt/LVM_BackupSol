package net.kkangsworld.lvmexec;

public class NativePipe {

	//test init
	public native String getMsg();
	public native String getPipe();
	public native String test_getPipe();
	public native int writePipe(String command);
	
	static
	{
		System.loadLibrary("LVMExec");
		
	}
}
